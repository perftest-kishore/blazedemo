Action()
{

	/* 1.Launch JPetstore Home Page */
	web_reg_find("Text=BIRDS",
		LAST);
	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_auto_header("Accept-Language", 
		"en-US,en;q=0.5");
	
	//actions/Catalog.action;jsessionid=B0017F6DE84EC962D5F817FE1A9B4C1B">
	
	web_reg_save_param_ex("ParamName=C_JessionId","LB=jsessionid=","RB=\">",LAST);

	lr_start_transaction("JPetStore_Shopping_T01_HomePage");

		web_url("Catalog.action", 
		"URL=https://petstore.octoperf.com/actions/Catalog.action", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("JPetStore_Shopping_T01_HomePage", LR_AUTO);

	/* 2.Click Sign In Button */

	web_reg_find("Text=Sign In",
		LAST);

	lr_start_transaction("JPetStore_Shopping_T02_SignIn");

		web_url("Sign In", 
		"URL=https://petstore.octoperf.com/actions/Account.action;jsessionid={C_JessionId}?signonForm=",   //B0017F6DE84EC962D5F817FE1A9B4C1B
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://petstore.octoperf.com/actions/Catalog.action", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("JPetStore_Shopping_T02_SignIn", LR_AUTO);

	web_reg_find("Text=Welcome ABC",
		LAST);
	
	/* 3. Enter Username & Password */
	lr_start_transaction("JPetStore_Shopping_T03_EnterUsernamePwd");

		web_submit_data("Account.action", 
		"Action=https://petstore.octoperf.com/actions/Account.action", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://petstore.octoperf.com/actions/Account.action;jsessionid={C_JessionId}?signonForm=",   //B0017F6DE84EC962D5F817FE1A9B4C1B
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=username", "Value=j2ee", ENDITEM, 
		"Name=password", "Value=j2ee", ENDITEM, 
		"Name=signon", "Value=Login", ENDITEM, 
		"Name=_sourcePage", "Value=o85W8Vl7e869hbMIbXTKrT3qIQKfUXtBp3tS8CsvizbeVNOJMJKphSeSEsymeZv0uiTLTPyeLtuCQ1dRf30FUaw2eOyhowf_TixdYHqT3YM=", ENDITEM, 
		"Name=__fp", "Value=PQyt3M9X2SOefPr5d1AVm4-Mb8a9kQZHvFouOKUaUKYCcJJngyhN3-TteRZsYy7e", ENDITEM, 
		LAST);


	lr_end_transaction("JPetStore_Shopping_T03_EnterUsernamePwd", LR_AUTO);

	/* 4. Click To Fish Tab */

	//viewProduct=&amp;productId=FI-SW-02">FI-SW-02</a></td>
	
	lr_think_time(36);
	
	web_reg_save_param_ex("ParamName=C_FishProductIds","LB=productId=","RB=\">","Ordinal=ALL",LAST);

	lr_start_transaction("JPetStore_Shopping_T04_NavigateToFishTab");

		web_url("sm_fish.gif", 
		"URL=https://petstore.octoperf.com/actions/Catalog.action?viewCategory=&categoryId=FISH", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://petstore.octoperf.com/actions/Catalog.action", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("JPetStore_Shopping_T04_NavigateToFishTab", LR_AUTO);

	
	lr_save_string(lr_paramarr_random("C_FishProductIds"),"C_FishProductIdRandomly");

	/* 5. Select Fish Randomly */

	lr_think_time(29);
	web_reg_find("Text=Product ID",
		LAST);

	//Catalog.action?viewItem=&amp;itemId=EST-3">EST-3</a></td>
	
	web_reg_save_param_ex("ParamName=C_FishItemIdsArray","LB=itemId=","RB=\">","Ordinal=ALL",LAST);

	lr_start_transaction("JPetStore_Shopping_T05_SelectFishRandomly");

		web_url("{C_FishProductIdRandomly}",     //  FI-SW-02
		"URL=https://petstore.octoperf.com/actions/Catalog.action?viewProduct=&productId={C_FishProductIdRandomly}",   // FI-SW-02
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://petstore.octoperf.com/actions/Catalog.action?viewCategory=&categoryId=FISH", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("JPetStore_Shopping_T05_SelectFishRandomly", LR_AUTO);

	lr_save_string(lr_paramarr_random("C_FishItemIdsArray"),"C_FishItemIdRandomly");

	web_reg_find("Text=Item ID",
		LAST);
	
	/* 6. Click Add to Cart Button */

	lr_think_time(18);
	
	web_reg_find("Text=Shopping Cart",
		LAST);
	
	lr_start_transaction("JPetStore_Shopping_T06_SelectedFishAddToCart");

		web_url("Add to Cart", 
		"URL=https://petstore.octoperf.com/actions/Cart.action?addItemToCart=&workingItemId={C_FishItemIdRandomly}",    //EST-3
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://petstore.octoperf.com/actions/Catalog.action?viewProduct=&productId={C_FishProductIdRandomly}",  //FI-SW-02
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("JPetStore_Shopping_T06_SelectedFishAddToCart", LR_AUTO);


	/* 7. Navigate To Dog Tab */

	//action?viewProduct=&amp;productId=K9-RT-01">
	lr_think_time(32);
	
	web_reg_find("Text=Dogs",
		LAST);

	web_reg_save_param_ex("ParamName=C_DogProductIdsArray","LB=productId=","RB=\">","Ordinal=ALL",LAST);

		lr_start_transaction("JPetStore_Shopping_T07_NavigateDogsTab");

		web_url("sm_dogs.gif", 
		"URL=https://petstore.octoperf.com/actions/Catalog.action?viewCategory=&categoryId=DOGS", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://petstore.octoperf.com/actions/Cart.action?addItemToCart=&workingItemId={C_FishItemIdRandomly}",    //EST-3
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("JPetStore_Shopping_T07_NavigateDogsTab", LR_AUTO);

	lr_save_string(lr_paramarr_random("C_DogProductIdsArray"),"C_DogProductIdRandomly");

	/* 8. Select One Dog Randomly */

	lr_think_time(22);
	//action?viewItem=&amp;itemId=EST-28">
	
	
	web_reg_save_param_ex("ParamName=C_DogItemIdsArray","LB=itemId=","RB=\">","Ordinal=ALL",LAST);

	lr_start_transaction("JPetStore_Shopping_T08_SelectDogRandomly");

		web_url("{C_DogProductIdRandomly}",     //K9-RT-01
		"URL=https://petstore.octoperf.com/actions/Catalog.action?viewProduct=&productId={C_DogProductIdRandomly}",     //K9-RT-01
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://petstore.octoperf.com/actions/Catalog.action?viewCategory=&categoryId=DOGS", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("JPetStore_Shopping_T08_SelectDogRandomly", LR_AUTO);
	
	lr_save_string(lr_paramarr_random("C_DogItemIdsArray"),"C_DogItemIdRandomly");

	/* 9. Click Add To Cart Button */

	lr_think_time(13);
	
	web_reg_find("Text=Quantity",
		LAST);

	lr_start_transaction("JPetStore_Shopping_T09_SelectedDogAddToCart");

		web_url("Add to Cart_2", 
		"URL=https://petstore.octoperf.com/actions/Cart.action?addItemToCart=&workingItemId={C_DogItemIdRandomly}",       //EST-28
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://petstore.octoperf.com/actions/Catalog.action?viewProduct=&productId={C_DogProductIdRandomly}",     //K9-RT-01
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("JPetStore_Shopping_T09_SelectedDogAddToCart", LR_AUTO);

	/* 10. Click Procedd To Checkout Button */

	lr_think_time(20);
	
	web_reg_find("Text=Payment Details",
		LAST);

	lr_start_transaction("JPetStore_Shopping_T10_ProceedToCheckout");

		web_url("Proceed to Checkout", 
		"URL=https://petstore.octoperf.com/actions/Order.action?newOrderForm=", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://petstore.octoperf.com/actions/Cart.action?addItemToCart=&workingItemId={C_DogItemIdRandomly}",    //EST-28
		"Snapshot=t12.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("JPetStore_Shopping_T10_ProceedToCheckout", LR_AUTO);

	/* 11. Enter Payment Details */

	lr_think_time(32);

	web_reg_find("Text=Please confirm the information",
		LAST);

	lr_start_transaction("JPetStore_Shopping_T11_EnterPaymentDetails");

		web_submit_data("Order.action", 
		"Action=https://petstore.octoperf.com/actions/Order.action", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://petstore.octoperf.com/actions/Order.action?newOrderForm=", 
		"Snapshot=t13.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=order.cardType", "Value=Visa", ENDITEM, 
		"Name=order.creditCard", "Value=999 9999 9999 9999", ENDITEM, 
		"Name=order.expiryDate", "Value=12/03", ENDITEM, 
		"Name=order.billToFirstName", "Value=swarna", ENDITEM, 
		"Name=order.billToLastName", "Value=latha", ENDITEM, 
		"Name=order.billAddress1", "Value=901 San Antonio Road", ENDITEM, 
		"Name=order.billAddress2", "Value=MS UCUP02-206", ENDITEM, 
		"Name=order.billCity", "Value=Palo Alto", ENDITEM, 
		"Name=order.billState", "Value=CA", ENDITEM, 
		"Name=order.billZip", "Value=94303", ENDITEM, 
		"Name=order.billCountry", "Value=USA", ENDITEM, 
		"Name=newOrder", "Value=Continue", ENDITEM, 
		"Name=_sourcePage", "Value=_SPQcwyTJoHXc1osvP58nij6UqXGwJ21u6NrGYHEwXzS_KrnrfTxxKGe9yyBXfaAa46RcT72lcxK1j-ZoPgP_cFDo5trgNNREWuzyRKQSyk=", ENDITEM, 
		"Name=__fp", "Value=Oifu-H7Z7P3I4Azoc_PhVpXmgZb67yc5WGamCcvZWUGXJ8JD35rzwn7Em-gW-2c0dyby5aH1JRGTOhJDM8YsRZusloU2BVcXT7I_dbSg3Ufg12mRHCGTXw==", ENDITEM, 
		LAST);


	lr_end_transaction("JPetStore_Shopping_T11_EnterPaymentDetails", LR_AUTO);

	/* 12. Click Confirm Order Button */

	lr_think_time(24);
	web_reg_find("Text=Thank you, your order",
		LAST);

	lr_start_transaction("JPetStore_Shopping_T12_ClickConfirmOrderButton");

		web_url("Confirm", 
		"URL=https://petstore.octoperf.com/actions/Order.action?newOrder=&confirmed=true", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://petstore.octoperf.com/actions/Order.action", 
		"Snapshot=t14.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("JPetStore_Shopping_T12_ClickConfirmOrderButton", LR_AUTO);

	web_reg_find("Text=REPTILES",
		LAST);

	/* 13. Click SignOut Button */

	lr_start_transaction("JPetStore_Shopping_T13_ClickSignout");

		web_url("Sign Out", 
		"URL=https://petstore.octoperf.com/actions/Account.action?signoff=", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://petstore.octoperf.com/actions/Order.action?newOrder=&confirmed=true", 
		"Snapshot=t15.inf", 
		"Mode=HTML", 
		LAST);


	lr_end_transaction("JPetStore_Shopping_T13_ClickSignout", LR_AUTO);

	return 0;
}