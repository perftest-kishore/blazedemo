Action()
{

	/* 1. Navigate to Blaze demo Ticket Reservation page */

	web_set_sockets_option("SSL_VERSION", "AUTO");
	
	web_set_max_html_param_len("99999");

	lr_think_time(15);
	
	web_reg_find("TEXT=The is a sample site you can test with BlazeMeter!", LAST);
	
	web_reg_save_param_ex("ParamName=C_DeptCitycode","LB=<select name=\"fromPort\" class=\"form-inline\">\n            ","RB=\n        </select>",LAST);

	web_reg_save_param_ex("ParamName=C_ArrvCitycode","LB=<select name=\"toPort\" class=\"form-inline\">\n            ","RB=\n        </select>",LAST);
	
	lr_start_transaction("Blazedemo_TC01_NavigateURL");

		web_url("index.php", 
		"URL=http://blazedemo.com/index.php", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://blazedemo.com/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	lr_end_transaction("Blazedemo_TC01_NavigateURL", LR_AUTO);

	lr_save_param_regexp(
		lr_eval_string("{C_DeptCitycode}"),
		strlen(lr_eval_string("{C_DeptCitycode}")),
		"RegExp=<option value=\"(.*?)\">",
		"Ordinal=ALL",
		"ResultParam=C_SelectDeptCityArray",LAST);
	
	lr_save_param_regexp(
		lr_eval_string("{C_ArrvCitycode}"),
		strlen(lr_eval_string("{C_ArrvCitycode}")),
		"RegExp=<option value=\"(.*?)\">",
		"Ordinal=ALL",
		"ResultParam=C_SelectArrvCityArray",LAST);
	
	lr_save_string(lr_paramarr_random("C_SelectDeptCityArray"), "C_SelectRandomDeptCity");
	
	lr_save_string(lr_paramarr_random("C_SelectArrvCityArray"), "C_SelectRandomArrvCity");
	
	
	/* 2. Select Departure city, Destination city & click Find Flights Button */

	lr_think_time(15);
	

	web_reg_save_param_ex(
		"ParamName=C_ChooseFlightArray",
		"LB=<td><input type=\"submit\" class=\"btn btn-small\" value=\"Choose This Flight\"></td>\n                ",
		"RB=\n            </form>",
		"Ordinal=ALL",
		SEARCH_FILTERS,
		LAST);


	
	web_reg_find("TEXT=Flights from {C_SelectRandomDeptCity} to {C_SelectRandomArrvCity}",LAST);
	
	lr_start_transaction("Blazedemo_TC02_SelectRandomCities");

		web_submit_data("reserve.php", 
		"Action=https://blazedemo.com/reserve.php", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://blazedemo.com/index.php", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=fromPort", "Value={C_SelectRandomDeptCity}", ENDITEM, //San Diego 
		"Name=toPort", "Value={C_SelectRandomArrvCity}", ENDITEM, //Berlin
		LAST);

	lr_end_transaction("Blazedemo_TC02_SelectRandomCities", LR_AUTO);
	
	lr_save_string(lr_paramarr_random("C_ChooseFlightArray"), "C_ChooseRandomFlight");
	
	lr_save_param_regexp(lr_eval_string("{C_ChooseRandomFlight}"), strlen(lr_eval_string("{C_ChooseRandomFlight}")),
	                     "RegExp=value=\"(.*?)\" name=\"flight\">","ordinal=all", "ResultParam=C_Flight", LAST);
	
	lr_save_param_regexp(lr_eval_string("{C_ChooseRandomFlight}"), strlen(lr_eval_string("{C_ChooseRandomFlight}")),
	                     "RegExp=value=\"(.*?)\" name=\"price\">","ordinal=all", "ResultParam=C_Price", LAST);
	                     
	lr_save_param_regexp(lr_eval_string("{C_ChooseRandomFlight}"), strlen(lr_eval_string("{C_ChooseRandomFlight}")),
	                     "RegExp=value=\"(.*?)\" name=\"airline\">","ordinal=all", "ResultParam=C_Airline", LAST);
	                                
	lr_save_string(lr_paramarr_random("C_Flight"),"C_RandomFlight");
	lr_save_string(lr_paramarr_random("C_Price"),"C_RandomPrice");
	lr_save_string(lr_paramarr_random("C_Airline"),"C_RandomAirline");

	

	/* 3. Choose a Flight randomly */

	lr_think_time(23);

	web_reg_find("TEXT=Please submit the form below to purchase the flight",LAST);
	
	lr_start_transaction("Blazedemo_TC03_ChooseRandomFlight");

		web_submit_data("purchase.php", 
		"Action=https://blazedemo.com/purchase.php", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://blazedemo.com/reserve.php", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=flight", "Value={C_RandomFlight}", ENDITEM, //9696
		"Name=price", "Value={C_RandomPrice}", ENDITEM, //200.98
		"Name=airline", "Value={C_RandomAirline}", ENDITEM, //Aer Lingus
		"Name=fromPort", "Value={C_SelectRandomDeptCity}", ENDITEM, 
		"Name=toPort", "Value={C_SelectRandomArrvCity}", ENDITEM, 
		LAST);

	lr_end_transaction("Blazedemo_TC03_ChooseRandomFlight", LR_AUTO);


	/* 4. Enter User info, Payment details and Click Purchase Ticket */

	lr_think_time(43);
	
	
	web_reg_find("TEXT=Thank you for your purchase today!", LAST);
	
	lr_start_transaction("Blazedemo_TC04_EnterDetails");

		web_submit_data("confirmation.php", 
		"Action=https://blazedemo.com/confirmation.php", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://blazedemo.com/purchase.php", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=_token", "Value=", ENDITEM, 
		"Name=inputName", "Value=Test", ENDITEM, 
		"Name=address", "Value=1234/B", ENDITEM, 
		"Name=city", "Value=Test City", ENDITEM, 
		"Name=state", "Value=Test state", ENDITEM, 
		"Name=zipCode", "Value=522503", ENDITEM, 
		"Name=cardType", "Value=amex", ENDITEM, 
		"Name=creditCardNumber", "Value=56756756767567", ENDITEM, 
		"Name=creditCardMonth", "Value=11", ENDITEM, 
		"Name=creditCardYear", "Value=2022", ENDITEM, 
		"Name=nameOnCard", "Value=Perf Test", ENDITEM, 
		LAST);

	lr_end_transaction("Blazedemo_TC04_EnterDetails", LR_AUTO);


	return 0;
}