Action()
{

	web_set_max_html_param_len("99999");
	
	web_reg_find("Text=departure city",
		LAST);
	
	/* 1.Navigation To BlazeDemo Home Page */

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_auto_header("Accept-Language", 
		"en-US,en;q=0.5");
	
	//<select name="fromPort" class="form-inline">
	//<select name="toPort" class="form-inline">
       // </select> 

       web_reg_save_param_ex("ParamName=C_FromPort","LB=<select name=\"fromPort\" class=\"form-inline\">\n            ","RB=\n        </select>",LAST);
       
       web_reg_save_param_ex("ParamName=C_ToPort","LB=<select name=\"toPort\" class=\"form-inline\">\n            ","RB=\n        </select>",LAST);
             
	lr_start_transaction("BlazeDemo_RandomTicketBooking_T01_ReservationPage");

		web_url("index.php", 
		"URL=https://blazedemo.com/index.php", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/favicon.ico", ENDITEM, 
		LAST);
       

	lr_end_transaction("BlazeDemo_RandomTicketBooking_T01_ReservationPage", LR_AUTO);
	
	//      <option value="Boston">Boston</option>
    
	lr_save_param_regexp(
		lr_eval_string("{C_FromPort}"),
		strlen(lr_eval_string("{C_FromPort}")),
		"RegExp=<option value=\"(.*?)\">",
		"Ordinal=ALL",
		"ResultParam=C_RandomDepCityArray",
		LAST );
	
	lr_save_param_regexp(
		lr_eval_string("{C_ToPort}"),
		strlen(lr_eval_string("{C_ToPort}")),
		"RegExp=<option value=\"(.*?)\">",
		"Ordinal=ALL",
		"ResultParam=C_RandomDestCityArray",
		LAST );

	lr_save_string(lr_paramarr_random("C_RandomDepCityArray"),"C_RandomDepCity");
	lr_save_string(lr_paramarr_random("C_RandomDestCityArray"),"C_RandomDestCity");
       

	/* 2.Select DepartureCity & DestinationCity And Click Find Flight Button */

	lr_think_time(6);

	//<td><input type="submit" class="btn btn-small" value="Choose This Flight"></td>
	// </form>
	
	web_reg_find("Text=Flights from",
		LAST);

	web_reg_save_param_ex("ParamName=C_FlightsInformation","LB=<input type=\"submit\" class=\"btn btn-small\" value=\"Choose This Flight\"></td>\n                ","RB=\n            </form>","Ordinal=ALL",LAST);
	
	lr_start_transaction("BlazeDemo_RandomTicketBooking_T02_SelectDepCityDestCity");

		web_submit_data("reserve.php", 
		"Action=https://blazedemo.com/reserve.php", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://blazedemo.com/index.php", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=fromPort", "Value={C_RandomDepCity}", ENDITEM,    //Boston
		"Name=toPort", "Value={C_RandomDestCity}", ENDITEM,      //London
		LAST);

	lr_end_transaction("BlazeDemo_RandomTicketBooking_T02_SelectDepCityDestCity", LR_AUTO);

	lr_save_string(lr_paramarr_random("C_FlightsInformation"),"C_FlightInfRandomly");

	// <input type="hidden" value="9696" name="flight">
      
    lr_save_param_regexp(
		lr_eval_string("{C_FlightInfRandomly}"),
		strlen(lr_eval_string("{C_FlightInfRandomly}")),
		"RegExp=value=\"(.*?)\" name=\"flight\">",
		"Ordinal=ALL",
		"ResultParam=C_RandomFlightNumber",
		LAST );

       //  <input type="hidden" value="200.98" name="price">
     
	lr_save_param_regexp(
		lr_eval_string("{C_FlightInfRandomly}"),
		strlen(lr_eval_string("{C_FlightInfRandomly}")),
		"RegExp=value=\"(.*?)\" name=\"price\">",
		"Ordinal=ALL",
		"ResultParam=C_RandomFlightPrice",
		LAST );

       //  <input type="hidden" value="Aer Lingus" name="airline">
    
	lr_save_param_regexp(
		lr_eval_string("{C_FlightInfRandomly}"),
		strlen(lr_eval_string("{C_FlightInfRandomly}")),
		"RegExp=value=\"(.*?)\" name=\"airline\">",
		"Ordinal=ALL",
		"ResultParam=C_RandomFlightName",
		LAST );      
      
	/* 3. Selct Flight Randomly */

	lr_think_time(20);

	web_reg_find("Text=Please submit",
		LAST);

	lr_start_transaction("BlazeDemo_RandomTicketBooking_T03_SelectFindFlight");

		web_submit_data("purchase.php", 
		"Action=https://blazedemo.com/purchase.php", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://blazedemo.com/reserve.php", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=flight", "Value={C_RandomFlightNumber}", ENDITEM,       //9696
		"Name=price", "Value={C_RandomFlightPrice}", ENDITEM,         //200.98
		"Name=airline", "Value={C_RandomFlightName}", ENDITEM,    //Aer Lingus
		"Name=fromPort", "Value={C_RandomDepCity}", ENDITEM,     //Boston
		"Name=toPort", "Value={C_RandomDestCity}", ENDITEM,       //London
		LAST);


	lr_end_transaction("BlazeDemo_RandomTicketBooking_T03_SelectFindFlight", LR_AUTO);
	
	/* 4.Enter Payment Details & Click Purchase Button */

	lr_think_time(28);
	
	web_reg_save_param_regexp(
		"ParamName=C_PurchaseId",
		"RegExp=<td>Id</td>(?:[\\\n\\s]*)<td>(.+?)</td>",
		SEARCH_FILTERS,
		LAST);

	web_reg_find("Text=Thank you",
		LAST);

	lr_start_transaction("BlazeDemo_RandomTicketBooking_T04_EnterPaymentDetails");

		web_submit_data("confirmation.php", 
		"Action=https://blazedemo.com/confirmation.php", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://blazedemo.com/purchase.php", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=_token", "Value=", ENDITEM, 
		"Name=inputName", "Value=Latha", ENDITEM, 
		"Name=address", "Value=", ENDITEM, 
		"Name=city", "Value=", ENDITEM, 
		"Name=state", "Value=", ENDITEM, 
		"Name=zipCode", "Value=", ENDITEM, 
		"Name=cardType", "Value=visa", ENDITEM, 
		"Name=creditCardNumber", "Value=", ENDITEM, 
		"Name=creditCardMonth", "Value=11", ENDITEM, 
		"Name=creditCardYear", "Value=2017", ENDITEM, 
		"Name=nameOnCard", "Value=", ENDITEM, 
		EXTRARES, 
		"Url=/favicon.ico", ENDITEM, 
		LAST);


	lr_end_transaction("BlazeDemo_RandomTicketBooking_T04_EnterPaymentDetails", LR_AUTO);

	return 0;
}