Action()
{

	/* 1.Navigate to  */

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_auto_header("Accept-Language", 
		"en-US,en;q=0.5");

	web_url("index.php", 
		"URL=https://blazedemo.com/index.php", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/favicon.ico", ENDITEM, 
		LAST);

	/* 2.Select DepartureCity & DestinationCity And Select Find Flights Button  */

	lr_think_time(16);

	web_submit_data("reserve.php", 
		"Action=https://blazedemo.com/reserve.php", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://blazedemo.com/index.php", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=fromPort", "Value=Portland", ENDITEM, 
		"Name=toPort", "Value=London", ENDITEM, 
		EXTRARES, 
		"Url=/favicon.ico", ENDITEM, 
		LAST);

	/* 3.Select Random Flight */

	lr_think_time(19);

	web_submit_data("purchase.php", 
		"Action=https://blazedemo.com/purchase.php", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://blazedemo.com/reserve.php", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=flight", "Value=4346", ENDITEM, 
		"Name=price", "Value=233.98", ENDITEM, 
		"Name=airline", "Value=Lufthansa", ENDITEM, 
		"Name=fromPort", "Value=Portland", ENDITEM, 
		"Name=toPort", "Value=London", ENDITEM, 
		LAST);

	/* 4.Enter Payment Details And click Purchase */

	lr_think_time(40);

	web_submit_data("confirmation.php", 
		"Action=https://blazedemo.com/confirmation.php", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://blazedemo.com/purchase.php", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=_token", "Value=", ENDITEM, 
		"Name=inputName", "Value=latha", ENDITEM, 
		"Name=address", "Value=", ENDITEM, 
		"Name=city", "Value=", ENDITEM, 
		"Name=state", "Value=", ENDITEM, 
		"Name=zipCode", "Value=", ENDITEM, 
		"Name=cardType", "Value=visa", ENDITEM, 
		"Name=creditCardNumber", "Value=", ENDITEM, 
		"Name=creditCardMonth", "Value=11", ENDITEM, 
		"Name=creditCardYear", "Value=2017", ENDITEM, 
		"Name=nameOnCard", "Value=", ENDITEM, 
		LAST);

	return 0;
}