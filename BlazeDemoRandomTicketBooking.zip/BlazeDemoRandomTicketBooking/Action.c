Action()
{

	web_set_max_html_param_len("99999");
	/* 1.Navigate to  */
	
	//<select name="fromPort" class="form-inline">
     //       <option value="Portland">Portland</option>
      //</select>
      //<select name="toPort" class="form-inline">

    //web_reg_save_param_ex("ParamName=C_Departurecity","LB=<option value=\"","RB=\">","Ordinal=ALL",LAST);
    
   	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_auto_header("Accept-Language", 
		"en-US,en;q=0.5");
   	
   	web_reg_save_param_ex("ParamName=C_FromCities","LB=<select name=\"fromPort\" class=\"form-inline\">\n            ","RB=\n        </select>",LAST);

   	web_reg_save_param_ex("ParamName=C_ToCities","LB=<select name=\"toPort\" class=\"form-inline\">\n            ","RB=\n        </select>",LAST);


	lr_start_transaction("BlazeDemo_RandomTicketBooking_T01_HomePage");

		web_url("index.php", 
		"URL=https://blazedemo.com/index.php", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/favicon.ico", ENDITEM, 
		LAST);

	lr_end_transaction("BlazeDemo_RandomTicketBooking_T01_HomePage", LR_AUTO);

   	
   	/*lr_save_param_regexp (
        bufferToSearch,
               strlen(bufferToSearch),
               "RegExp=(XX..YY)",
               "Ordinal=All",
               "ResultParam=reMatchesParam",
               LAST );  */
	
	lr_save_param_regexp(
		lr_eval_string("{C_FromCities}"),
		strlen(lr_eval_string("{C_FromCities}")),
		"RegExp=<option value=\"(.*?)\">",
		"Ordinal=ALL",
		"ResultParam=C_RandomDepCityArray",
		LAST );
	
	lr_save_param_regexp(
		lr_eval_string("{C_ToCities}"),
		strlen(lr_eval_string("{C_ToCities}")),
		"RegExp=<option value=\"(.*?)\">",
		"Ordinal=ALL",
		"ResultParam=C_RandomDestCityArray",
		LAST );
   	
   	lr_save_string(lr_paramarr_random("C_RandomDepCityArray"),"C_RandomDepCity");
	lr_save_string(lr_paramarr_random("C_RandomDestCityArray"),"C_RandomDestCity");
   	
	
	/* 2.Select DepartureCity & DestinationCity And Select Find Flights Button  */

	lr_think_time(16);

	lr_start_transaction("BlazeDemo_RandomTicketBooking_T02_SelectDepCityDestCity");

		web_submit_data("reserve.php", 
		"Action=https://blazedemo.com/reserve.php", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://blazedemo.com/index.php", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=fromPort", "Value={C_RandomDepCity}", ENDITEM,    //Portland
		"Name=toPort", "Value={C_RandomDestCity}", ENDITEM,       //London
		EXTRARES, 
		"Url=/favicon.ico", ENDITEM, 
		LAST);

	lr_end_transaction("BlazeDemo_RandomTicketBooking_T02_SelectDepCityDestCity", LR_AUTO);


	/* 3.Select Random Flight */

	lr_think_time(19);

	lr_start_transaction("BlazeDemo_RandomTicketBooking_T03_SelectRandomFlight");

		web_submit_data("purchase.php", 
		"Action=https://blazedemo.com/purchase.php", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://blazedemo.com/reserve.php", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=flight", "Value=4346", ENDITEM, 
		"Name=price", "Value=233.98", ENDITEM, 
		"Name=airline", "Value=Lufthansa", ENDITEM, 
		"Name=fromPort", "Value={C_RandomDepCity}", ENDITEM,        //Portland
		"Name=toPort", "Value={C_RandomDestCity}", ENDITEM,            //London
		LAST);


	lr_end_transaction("BlazeDemo_RandomTicketBooking_T03_SelectRandomFlight", LR_AUTO);

	/* 4.Enter Payment Details And click Purchase */

	lr_think_time(40);

	lr_start_transaction("BlazeDemo_RandomTicketBooking_T04_EnterPaymentDetails");

		web_submit_data("confirmation.php", 
		"Action=https://blazedemo.com/confirmation.php", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://blazedemo.com/purchase.php", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=_token", "Value=", ENDITEM, 
		"Name=inputName", "Value=latha", ENDITEM, 
		"Name=address", "Value=", ENDITEM, 
		"Name=city", "Value=", ENDITEM, 
		"Name=state", "Value=", ENDITEM, 
		"Name=zipCode", "Value=", ENDITEM, 
		"Name=cardType", "Value=visa", ENDITEM, 
		"Name=creditCardNumber", "Value=", ENDITEM, 
		"Name=creditCardMonth", "Value=11", ENDITEM, 
		"Name=creditCardYear", "Value=2017", ENDITEM, 
		"Name=nameOnCard", "Value=", ENDITEM, 
		LAST);

	lr_end_transaction("BlazeDemo_RandomTicketBooking_T04_EnterPaymentDetails", LR_AUTO);


	return 0;
}