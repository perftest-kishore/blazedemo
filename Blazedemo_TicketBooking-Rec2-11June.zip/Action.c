Action()
{

	web_set_sockets_option("SSL_VERSION", "AUTO");
	web_set_max_html_param_len("99999");
	
	/* 1.Navigate to Blaze demo Ticket Reservation page */
	//web_reg_save_param_ex("ParamName=C_fromCityCode","LB=<select name=\"fromPort\" class=\"form-inline\">\n        ","RB=\n        </select>",LAST)
	
	
	web_url("index.php", 
		"URL=http://blazedemo.com/index.php", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://blazedemo.com/favicon.ico", "Referer=https://blazedemo.com/index.php", ENDITEM, 
		LAST);

	/* 2.Select Departure city, Destination city & click Find Flights Button */

	lr_think_time(8);

	web_submit_data("reserve.php", 
		"Action=https://blazedemo.com/reserve.php", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://blazedemo.com/index.php", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=fromPort", "Value=Philadelphia", ENDITEM, 
		"Name=toPort", "Value=Rome", ENDITEM, 
		LAST);

	/* 3.Choose a Flight randomly */

	lr_think_time(23);

	web_submit_data("purchase.php", 
		"Action=https://blazedemo.com/purchase.php", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://blazedemo.com/reserve.php", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=flight", "Value=12", ENDITEM, 
		"Name=price", "Value=765.32", ENDITEM, 
		"Name=airline", "Value=Virgin America", ENDITEM, 
		"Name=fromPort", "Value=Philadelphia", ENDITEM, 
		"Name=toPort", "Value=Rome", ENDITEM, 
		LAST);

	/* 4.Enter User info, Payment details and Click Purchase Ticket */

	lr_think_time(57);

	web_submit_data("confirmation.php", 
		"Action=https://blazedemo.com/confirmation.php", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://blazedemo.com/purchase.php", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=_token", "Value=", ENDITEM, 
		"Name=inputName", "Value=Mahi", ENDITEM, 
		"Name=address", "Value=1233", ENDITEM, 
		"Name=city", "Value=Hyderabad", ENDITEM, 
		"Name=state", "Value=TS", ENDITEM, 
		"Name=zipCode", "Value=524341", ENDITEM, 
		"Name=cardType", "Value=visa", ENDITEM, 
		"Name=creditCardNumber", "Value=123456", ENDITEM, 
		"Name=creditCardMonth", "Value=11", ENDITEM, 
		"Name=creditCardYear", "Value=2017", ENDITEM, 
		"Name=nameOnCard", "Value=gvjhvjvkhd", ENDITEM, 
		LAST);

	return 0;
}