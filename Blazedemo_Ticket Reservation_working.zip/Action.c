Action()
{
   web_set_max_html_param_len("99999");
   
	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_auto_header("Accept-Encoding", 
		"gzip, deflate, br");

	

	

	web_add_auto_header("Accept-Language", 
		"en-US,en;q=0.9");

	web_add_auto_header("User-Agent", 
		"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.101 Safari/537.36");
	
    lr_start_transaction("Blazedemo_TR01_ApplicationLaunch");

	web_reg_save_param_ex(
		"ParamName=C_fromCityCode",
		"LB=<select name=\"fromPort\" class=\"form-inline\">\n            ",
		"RB=\n        </select>",
		//"Ordinal=ALL",
		//SEARCH_FILTERS,
		LAST);

	web_reg_save_param_ex(
		"ParamName=C_ToCityCode",
		"LB=<select name=\"toPort\" class=\"form-inline\">",
		"RB=</select>",
		//"Ordinal=ALL",
		//SEARCH_FILTERS,
		LAST);

     
	  
	web_url("index.php", 
		"URL=https://blazedemo.com/index.php", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		LAST);
	
	 lr_save_param_regexp (
		lr_eval_string("{C_fromCityCode}"),
		strlen(lr_eval_string("{C_fromCityCode}")),
               "RegExp=<option value=\"(.*?)\">",   
               "Ordinal=ALL",
               "ResultParam=C_DepartureCitiesarray",
               LAST );
	
	lr_save_param_regexp (
		lr_eval_string("{C_ToCityCode}"),
		strlen(lr_eval_string("{C_ToCityCode}")),
               "RegExp=<option value=\"(.*?)\">",   
               "Ordinal=ALL",
               "ResultParam=C_arraivalCitiesarray",
               LAST );
	
	lr_save_string(lr_paramarr_random("C_DepartureCitiesarray"),"C_randomDeptCity");
	
	lr_save_string(lr_paramarr_random("C_arraivalCitiesarray"),"C_randomArrivCity");
	
		lr_end_transaction("Blazedemo_TR01_ApplicationLaunch", LR_AUTO);

		
	/* 2.Select Departure city, Destination city & click Find Flights Button */

	lr_think_time(41);
    
	
	lr_start_transaction("Blazedemo_TR02_Select Departure city&Destination city");


	web_reg_save_param_ex(
		"ParamName=C_Flightdetails",
		"LB=<input type=\"submit\" class=\"btn btn-small\" value=\"Choose This Flight\">",
		"RB=</form>",
		SEARCH_FILTERS,
		LAST);

	web_submit_data("reserve.php", 
		"Action=https://blazedemo.com/reserve.php", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://blazedemo.com/index.php", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=fromPort", "Value={C_randomDeptCity}", ENDITEM, //Paris
		"Name=toPort", "Value={C_randomArrivCity}", ENDITEM, //London
		LAST);


	lr_save_param_regexp (
		lr_eval_string("{C_Flightdetails}"),
		strlen(lr_eval_string("{C_Flightdetails}")),
               "RegExp=<input type=\"hidden\" value=\"(.*?)\" name=\"flight\">",      //<input type="hidden" value="12" name="flight">  
               "ResultParam=C_FlightId",
               LAST );
	
	lr_save_param_regexp (
		lr_eval_string("{C_Flightdetails}"),
		strlen(lr_eval_string("{C_Flightdetails}")),
               "RegExp= <input type=\"hidden\" value=\"(.*?)\" name=\"price\">",        
               "ResultParam=C_Price",
               LAST );
	
		
	lr_save_param_regexp (
		lr_eval_string("{C_Flightdetails}"),
		strlen(lr_eval_string("{C_Flightdetails}")),
               "RegExp= <input type=\"hidden\" value=\"(.*?)\" name=\"airline\">",        
               "ResultParam=C_airline",
               LAST );
	lr_end_transaction("Blazedemo_TR02_Select Departure city&Destination city", LR_AUTO);

     /*3.Choose a Flight randomly*/
lr_start_transaction("Blazedemo_TR03_Choose RandomFlight");

	web_submit_data("purchase.php", 
		"Action=https://blazedemo.com/purchase.php", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://blazedemo.com/reserve.php", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=flight", "Value={C_FlightId}", ENDITEM, //12
		"Name=price", "Value={C_Price}", ENDITEM,  //765.32
		"Name=airline", "Value={C_airline}", ENDITEM, //Virgin America
		"Name=fromPort", "Value={C_randomDeptCity}", ENDITEM, //Paris
		"Name=toPort", "Value={C_randomArrivCity}", ENDITEM, //London
		LAST);
lr_end_transaction("Blazedemo_TR03_Choose RandomFlight", LR_AUTO);

      
	/* 4.Enter User info, Payment details and Click Purchase Ticket */

	lr_think_time(49);

	lr_start_transaction("Blazedemo_TR04_Payment");

		web_submit_data("confirmation.php", 
		"Action=https://blazedemo.com/confirmation.php", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://blazedemo.com/purchase.php", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=_token", "Value=", ENDITEM, 
		"Name=inputName", "Value={P_Name}", ENDITEM, 
		"Name=address", "Value={P_Address}", ENDITEM, 
		"Name=city", "Value={P_city}", ENDITEM, 
		"Name=state", "Value={P_state}", ENDITEM, 
		"Name=zipCode", "Value={P_Zipcode}", ENDITEM, 
		"Name=cardType", "Value={P_cardtype}", ENDITEM, 
		"Name=creditCardNumber", "Value={P_cardnumber}", ENDITEM, 
		"Name=creditCardMonth", "Value={P_month}", ENDITEM, 
		"Name=creditCardYear", "Value={P_cardYear}", ENDITEM, 
		"Name=nameOnCard", "Value={P_NameonCard}", ENDITEM, 
		LAST);

	lr_end_transaction("Blazedemo_TR04_Payment", LR_AUTO);


	return 0;
}