Action()
{

	/* 1 navigate to blaze demo ticket reservation page */
	
	lr_think_time(10);
	lr_start_transaction("blazdemo_t01_navigate to reservation page");

	web_reg_find("text=The is a sample site you can test with BlazeMeter!",LAST);
	web_set_max_html_param_len("99999");
	web_set_sockets_option("SSL_VERSION", "AUTO");
	web_reg_save_param_ex("ParamName=C_fromcitycode","LB=<select name=\"fromPort\" class=\"form-inline\">","RB=</select>",LAST);
	web_reg_save_param_ex("ParamName=C_ToportCode","LB=<select name=\"toPort\" class=\"form-inline\">","RB=</select>",LAST);
	web_url("index.php", 
		"URL=https://blazedemo.com/index.php", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/favicon.ico", ENDITEM, 
		LAST);
	lr_save_param_regexp (
		lr_eval_string("{C_fromcitycode}"),
               strlen(lr_eval_string("{C_fromcitycode}")),
               "RegExp=<option value=\"(.*)\">",
               "Ordinal=All",
               "ResultParam=C_fromcityarray",
               LAST );
	lr_save_param_regexp (
		lr_eval_string("{C_ToportCode}"),
               strlen(lr_eval_string("{C_ToportCode}")),
               "RegExp=<option value=\"(.*)\">",
               "Ordinal=All",
               "ResultParam=C_ToCityArray",
               LAST );
	lr_save_string(lr_paramarr_random("C_fromcityarray"),"C_randomDepaturecity");
	lr_save_string(lr_paramarr_random("C_ToCityArray"),"C_RandomDestinationcity");
lr_end_transaction("blazdemo_t01_navigate to reservation page", LR_AUTO);

	/* 2 choose departure,destination city and click find flights */

	lr_think_time(10);
	lr_start_transaction("blazedemo_t02_choose departure...clickflight");

	web_reg_find("text=Choose",LAST);
	web_reg_save_param_ex("ParamName=C_FlightOptionArray","LB=<form name=\"","RB=</form>","ordinal=all",LAST);
	web_submit_data("reserve.php", 
		"Action=https://blazedemo.com/reserve.php", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://blazedemo.com/index.php",
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=fromPort", "Value={C_randomDepaturecity}", ENDITEM, //paris
		"Name=toPort", "Value={C_RandomDestinationcity}", ENDITEM, //london
		LAST);
	lr_save_string(lr_paramarr_random("C_FlightOptionArray"),"C_RandomFlightCode");
	
	//<input type="hidden" value="43" name="flight">
    //<input type="hidden" value="472.56" name="price">
    //<input type="hidden" value="Virgin America" name="airline">
   
//flight no
  lr_save_param_regexp (
	lr_eval_string("{C_RandomFlightCode}"),
               strlen(lr_eval_string("{C_RandomFlightCode}")),
               "RegExp=<input type=\"hidden\" value=\"(.*)\" name=\"flight\">",
               "Ordinal=1",
               "ResultParam=C_RandomFlightNumber",
               LAST );

//ticket price

   lr_save_param_regexp (
	lr_eval_string("{C_RandomFlightCode}"),
               strlen(lr_eval_string("{C_RandomFlightCode}")),
               "RegExp=<input type=\"hidden\" value=\"(.*)\" name=\"price\">",
               "Ordinal=1",
               "ResultParam=C_RandomTicketPrice",
               LAST );
//airline name

   lr_save_param_regexp (
	lr_eval_string("{C_RandomFlightCode}"),
               strlen(lr_eval_string("{C_RandomFlightCode}")),
               "RegExp=<input type=\"hidden\" value=\"(.*)\" name=\"airline\">",
               "Ordinal=1",
               "ResultParam=C_airlineName",
               LAST );            
 lr_end_transaction("blazedemo_t02_choose departure...clickflight", LR_AUTO);
              
	
/* 3 choose a flight random,selected first*/

	lr_think_time(10);
	lr_start_transaction("blazedemo_t03_choose a flight random,selected first");

web_reg_find("text=Total Cost:",LAST);
	web_submit_data("purchase.php", 
		"Action=https://blazedemo.com/purchase.php", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://blazedemo.com/reserve.php", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=flight", "Value={C_RandomFlightNumber}", ENDITEM, 
		"Name=price", "Value={C_RandomTicketPrice}", ENDITEM, 
		"Name=airline", "Value={C_airlineName}", ENDITEM, 
		"Name=fromPort", "Value={C_randomDepaturecity}", ENDITEM, //paris
		"Name=toPort", "Value={C_RandomDestinationcity}", ENDITEM, //london
		LAST);
lr_end_transaction("blazedemo_t03_choose a flight random,selected first", LR_AUTO);

	
	/* 4 enter userinfo payment details and click purchase flight */

	lr_think_time(10);
	lr_start_transaction("blazedemo_t04_enter userinfo payment details and click purchase flight");

	web_reg_find("text=Thank you for your purchase today!",LAST);
	web_submit_data("confirmation.php", 
		"Action=https://blazedemo.com/confirmation.php", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://blazedemo.com/purchase.php", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=_token", "Value=", ENDITEM, 
		"Name=inputName", "Value=kumar", ENDITEM, 
		"Name=address", "Value=123main street", ENDITEM, 
		"Name=city", "Value=vizag", ENDITEM, 
		"Name=state", "Value=state", ENDITEM, 
		"Name=zipCode", "Value=532541", ENDITEM, 
		"Name=cardType", "Value=visa", ENDITEM, 
		"Name=creditCardNumber", "Value=13256564", ENDITEM, 
		"Name=creditCardMonth", "Value=1", ENDITEM, 
		"Name=creditCardYear", "Value=2021", ENDITEM, 
		"Name=nameOnCard", "Value=kumar", ENDITEM, 
		LAST);
lr_end_transaction("blazedemo_t04_enter userinfo payment details and click purchase flight", LR_AUTO);

	return 0;
}