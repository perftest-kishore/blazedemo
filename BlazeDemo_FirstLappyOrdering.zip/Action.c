Action()
{

	/* 1.Navigate to Blaze demo Ticket Reservation page */

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_auto_header("DNT", 
		"1");

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");
	
	
	web_add_auto_header("Origin", 
		"https://blazedemo.com");

	
	web_set_max_html_param_len("99999");
	

	web_reg_save_param_ex(
		"ParamName=c_DepCityArray",
		"LB=<select name=\"fromPort\" class=\"form-inline\">\n            ",
		"RB=\n        </select>",
		SEARCH_FILTERS,
		LAST);
	
	web_reg_save_param_ex(
		"ParamName=c_ArrCityArray",
		"LB=<select name=\"toPort\" class=\"form-inline\">\n            ",
		"RB=\n        </select>",
		SEARCH_FILTERS,
		LAST);

 	web_url("index.php", 
		"URL=http://blazedemo.com/index.php", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://blazedemo.com/favicon.ico", "Referer=https://blazedemo.com/index.php", ENDITEM, 
		LAST);

	
	lr_save_param_regexp(lr_eval_string("{c_DepCityArray}"),strlen(lr_eval_string("{c_DepCityArray}")),
	                     "RegExp = <option value=\"(.*?)\">",
	                     "Ordinal = ALL",
	                     "ResultParam=c_DepCity",LAST);
	
	lr_save_param_regexp(lr_eval_string("{c_ArrCityArray}"),strlen(lr_eval_string("{c_ArrCityArray}")),
	                     "RegExp = <option value=\"(.*?)\">",
	                     "Ordinal = ALL",
	                     "ResultParam=c_ArrivalCity",LAST);

    

	lr_save_string(lr_paramarr_random("c_DepCity"), "C_Random_depcity");
	lr_save_string(lr_paramarr_random("c_ArrivalCity"), "C_Random_Arrcity");


	/* 2Select Departure city, Destination city & click Find Flights Button */
	
	web_reg_save_param_ex(
		"ParamName=C_Flightdetails",
		"LB=<input type=\"submit\" class=\"btn btn-small\" value=\"Choose This Flight\">",
		"RB=</form>",
		"Ordinal=ALL",
		SEARCH_FILTERS,
		LAST);
	
	lr_think_time(12);

	web_submit_data("reserve.php", 
		"Action=https://blazedemo.com/reserve.php", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://blazedemo.com/index.php", 
		"Snaphot=t2.inf", 
		"Mode=HTML", 
		ITEMDATA, 
	    "Name=fromPort", "Value={C_Random_depcity}", ENDITEM, //Philadelphia
		"Name=toPort", "Value={C_Random_Arrcity}", ENDITEM, //London
		LAST);
        
	/*    lr_save_param_regexp (
		lr_eval_string("{C_Flightdetails}"),
		strlen(lr_eval_string("{C_Flightdetails}")),
               "RegExp=<input type=\"hidden\" value=\"(.*?)\" name=\"flight\">",      //<input type="hidden" value="12" name="flight">  
               "ResultParam=C_FlightId",
               LAST );*/
	
	return 0;
	
	/* 3.Choose a Flight randomly */

	lr_think_time(6);

	//<input type="hidden" value="234" name="flight">
	

	web_submit_data("purchase.php", 
		"Action=https://blazedemo.com/purchase.php", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://blazedemo.com/reserve.php", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=flight", "Value=234", ENDITEM, 
		"Name=price", "Value=432.98", ENDITEM, 
		"Name=airline", "Value=United Airlines", ENDITEM, 
		"Name=fromPort", "Value={c_DepCity}", ENDITEM, 
		"Name=toPort", "Value={c_ArrivalCity}", ENDITEM, 
		LAST);
	

	
	/* 4.Enter User info, Payment details and Click Purchase Ticket */

	lr_think_time(26);

	web_submit_data("confirmation.php", 
		"Action=https://blazedemo.com/confirmation.php", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://blazedemo.com/purchase.php", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=_token", "Value=", ENDITEM, 
		"Name=inputName", "Value=", ENDITEM, 
		"Name=address", "Value=", ENDITEM, 
		"Name=city", "Value=", ENDITEM, 
		"Name=state", "Value=", ENDITEM, 
		"Name=zipCode", "Value=", ENDITEM, 
		"Name=cardType", "Value=visa", ENDITEM, 
		"Name=creditCardNumber", "Value=12345678", ENDITEM, 
		"Name=creditCardMonth", "Value=11", ENDITEM, 
		"Name=creditCardYear", "Value=2017", ENDITEM, 
		"Name=nameOnCard", "Value=", ENDITEM, 
		LAST);

	return 0;
}