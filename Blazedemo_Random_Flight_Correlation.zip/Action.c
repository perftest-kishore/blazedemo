Action()
{

	/* 1. Navigate to Blaze demo Ticket Reservation page
	*/

	lr_start_transaction("1. Navigate to Blaze demo Ticket Reservation page");
	
	web_set_max_html_param_len("99999");


	web_set_sockets_option("SSL_VERSION", "AUTO");
	
	
	//LB=  <select name="toPort" class="form-inline">
	//RB= </select>
	
	web_reg_save_param_ex("ParamName=C_DepartCityArray","LB=<select name=\"fromPort\" class=\"form-inline\">\n            ","RB=\n        </select>",LAST);

	
	web_reg_save_param_ex("ParamName=C_ArrivalCityArray","LB=<select name=\"toPort\" class=\"form-inline\">\n            ","RB=\n        </select>",LAST);

	                      
	web_url("index.php",
		"URL=https://blazedemo.com/index.php", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/favicon.ico", ENDITEM, 
		LAST);
	lr_save_param_regexp (
		lr_eval_string("{C_DepartCityArray}"),
		strlen(lr_eval_string("{C_DepartCityArray}")),
               "RegExp=<option value=\"(.*?)\">",
               "Ordinal=All",
               "ResultParam=C_DepatCity",
               LAST );
	
	lr_save_param_regexp (
		lr_eval_string("{C_ArrivalCityArray}"),
		strlen(lr_eval_string("{C_ArrivalCityArray}")),
               "RegExp=<option value=\"(.*?)\">",
               "Ordinal=All",
               "ResultParam=C_ArrivalCity",
               LAST );


	lr_end_transaction("1. Navigate to Blaze demo Ticket Reservation page",LR_AUTO);
	
	
	/* 2. Select Departure city Destination city & click Find Flights Button
	*/

	lr_think_time(31);

	lr_start_transaction("2. Select Departure city Destination city & click Find Flights Button");

	web_submit_data("reserve.php", 
		"Action=https://blazedemo.com/reserve.php", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://blazedemo.com/index.php", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=fromPort", "Value={C_DepartCityArray}", ENDITEM, 
		"Name=toPort", "Value={C_ArrivalCityArray}", ENDITEM, 
		LAST);

	lr_end_transaction("2. Select Departure city Destination city & click Find Flights Button",LR_AUTO);

	/* 3. Choose a Flight randomly
	*/

	lr_think_time(8);

	lr_start_transaction("3. Choose a Flight randomly");

	web_submit_data("purchase.php", 
		"Action=https://blazedemo.com/purchase.php", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://blazedemo.com/reserve.php", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=flight", "Value=234", ENDITEM, 
		"Name=price", "Value=432.98", ENDITEM, 
		"Name=airline", "Value=United Airlines", ENDITEM, 
		"Name=fromPort", "Value=Paris", ENDITEM, 
		"Name=toPort", "Value=London", ENDITEM, 
		LAST);

	lr_end_transaction("3. Choose a Flight randomly",LR_AUTO);

	/* 4. Enter User info Payment details and Click Purchase Ticket
	*/

	lr_think_time(110);

	lr_start_transaction("4. Enter User Info");

	web_submit_data("confirmation.php", 
		"Action=https://blazedemo.com/confirmation.php", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://blazedemo.com/purchase.php", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=_token", "Value=", ENDITEM, 
		"Name=inputName", "Value=sample1", ENDITEM, 
		"Name=address", "Value=address1", ENDITEM, 
		"Name=city", "Value=Vijayawada", ENDITEM, 
		"Name=state", "Value=Andhra Pradesh", ENDITEM, 
		"Name=zipCode", "Value=520002", ENDITEM, 
		"Name=cardType", "Value=amex", ENDITEM, 
		"Name=creditCardNumber", "Value=1234567890", ENDITEM, 
		"Name=creditCardMonth", "Value=11", ENDITEM, 
		"Name=creditCardYear", "Value=2017", ENDITEM, 
		"Name=nameOnCard", "Value=sample1", ENDITEM, 
		LAST);

	lr_end_transaction("4. Enter User Info",LR_AUTO);

	return 0;
}