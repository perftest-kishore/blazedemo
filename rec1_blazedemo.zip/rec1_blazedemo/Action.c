Action()
{

	
	
	web_set_max_html_param_len("789456");
	
	web_reg_save_param_ex("ParamName=c_destination","LB=<select name=\"fromPort\" class=\"form-inline\">","RB=</select>",LAST);
	
	
	web_reg_save_param_ex("ParamName=c_arrival","LB=<select name=\"toPort\" class=\"form-inline\">","RB=</select>",LAST);
	
	/* 1.Launch blazedemo site */
	
	

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_url("blazedemo.com", 
		"URL=http://blazedemo.com/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://blazedemo.com/favicon.ico", "Referer=https://blazedemo.com/", ENDITEM, 
		LAST);
	
	lr_save_param_regexp (
		lr_eval_string("{c_destination}"),
               strlen(lr_eval_string("{c_destination}")),
               "RegExp=<option value=\"(.*)\">",
               "Ordinal=All",
               "ResultParam=destinationcityarray",
               LAST );
	
	lr_save_param_regexp (
		lr_eval_string("{c_arrival}"),
               strlen(lr_eval_string("{c_arrival}")),
               "RegExp=<option value=\"(.*)\">",
               "Ordinal=All",
               "ResultParam=arrivalcityarray",
               LAST );
	
	
	
	
	lr_save_string(lr_paramarr_random("destinationcityarray"),"c_destinationcity");
	
	
		lr_save_string(lr_paramarr_random("arrivalcityarray"),"c_arrival");



	/* 2.select depaturecity and destination city */

	lr_think_time(8);

	web_reg_save_param_ex("ParamName=c_chooseflight","LB=<form","RB=</form>","Ordinal=All",LAST);
	
	
	web_submit_data("reserve.php", 
		"Action=https://blazedemo.com/reserve.php", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://blazedemo.com/", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=fromPort", "Value={c_destinationcity}", ENDITEM, 
		"Name=toPort", "Value={c_arrival}", ENDITEM, 
		LAST);

	/* 3.choose flight */

	web_submit_data("purchase.php", 
		"Action=https://blazedemo.com/purchase.php", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://blazedemo.com/reserve.php", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=flight", "Value={c_flightvalue}", ENDITEM, 
		"Name=price", "Value={c_price}", ENDITEM, 
		"Name=airline", "Value={c_airline}", ENDITEM, 
		"Name=fromPort", "Value={c_destinationcity}", ENDITEM, 
		"Name=toPort", "Value={c_arrival}", ENDITEM, 
		LAST);

	lr_save_string(lr_paramarr_random("c_chooseflight"),"chooseflightname");
	
	
	lr_save_param_regexp(lr_eval_string("{chooseflightname}"),strlen(lr_eval_string("{chooseflightname}")),"Regexp=<input type=\"hidden\" value=\"(.*)\" name=\"flight\">","Ordinal=All","ResultParam=c_flightvalue",LAST);	
	
	lr_save_param_regexp(lr_eval_string("{chooseflightname}"),strlen(lr_eval_string("{chooseflightname}")),"Regexp=<input type=\"hidden\" value=\"(.*)\" name=\"price\">","Ordinal=All","ResultParam=c_price",LAST);	
	
	
		lr_save_param_regexp(lr_eval_string("{chooseflightname}"),strlen(lr_eval_string("{chooseflightname}")),"Regexp=<input type=\"hidden\" value=\"(.*)\" name=\"airline\">","ResultParam=c_airline",LAST);
	
		
		lr_save_param_regexp(lr_eval_string("{chooseflightname}"),strlen(lr_eval_string("{chooseflightname}")),"Regexp=<input type=\"hidden\" name=\"fromPort\" value=\"(.*)\"/>","ResultParam=c_fromcity",LAST);
		
	
		lr_save_param_regexp(lr_eval_string("{chooseflightname}"),strlen(lr_eval_string("{chooseflightname}")),"Regexp=<input type=\"hidden\" name=\"fromPort\" value=\"(.*)\"/>","ResultParam=c_toport",LAST);
	
		
		
	
	/* 4.enter details */

	lr_think_time(15);

	web_submit_data("confirmation.php", 
		"Action=https://blazedemo.com/confirmation.php", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://blazedemo.com/purchase.php", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=_token", "Value=", ENDITEM, 
		"Name=inputName", "Value=abc", ENDITEM, 
		"Name=address", "Value=test", ENDITEM, 
		"Name=city", "Value=test", ENDITEM, 
		"Name=state", "Value=test", ENDITEM, 
		"Name=zipCode", "Value=132222", ENDITEM, 
		"Name=cardType", "Value=visa", ENDITEM, 
		"Name=creditCardNumber", "Value=112312321312312", ENDITEM, 
		"Name=creditCardMonth", "Value=11", ENDITEM, 
		"Name=creditCardYear", "Value=2017", ENDITEM, 
		"Name=nameOnCard", "Value=test222", ENDITEM, 
		"Name=rememberMe", "Value=on", ENDITEM, 
		LAST);

	return 0;
}