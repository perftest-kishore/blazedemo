		Action()
		{
		
			web_set_sockets_option("SSL_VERSION", "AUTO");
			web_set_max_html_param_len("70000");
		
			web_add_auto_header("Accept-Language", 
				"en-US,en;q=0.5");
		/* Launch blazedemo navigation page */
		//<option value=\".*?"
		lr_think_time(10);
		 
		/*Correlation comment - Do not change!  Original value='Portland' Name ='fromPort' Type ='Manual'*/
			web_reg_save_param_ex("ParamName=FromPortCities","LB=<select name=\"fromPort\" class=\"form-inline\">","RB=</select>",LAST);
			web_reg_save_param_ex("ParamName=ToPortCities","LB=<select name=\"toPort\" class=\"form-inline\">","RB=</select>",LAST);
       		web_reg_find("Text=Welcome to the Simple Travel Agency!",LAST);
    lr_start_transaction("Blazedemo_launchpage_T01");
			web_url("www.blazedemo.com", 
				"URL=https://www.blazedemo.com/", 
				"TargetFrame=", 
				"Resource=0", 
				"RecContentType=text/html", 
				"Referer=", 
				"Snapshot=t1.inf", 
				"Mode=HTML", 
				EXTRARES, 
				"Url=/favicon.ico", ENDITEM, 
				LAST);
	lr_end_transaction("Blazedemo_launchpage_T01",LR_AUTO);
	lr_think_time(10);
		  lr_save_param_regexp (
		       lr_eval_string("{FromPortCities}"),
		      	   strlen(lr_eval_string("{FromPortCities}")),
		               "RegExp=<option value=\"(.*?)\">",
		               "Ordinal=All",
		               "ResultParam=DepartureCityArray",//capturing departure cities into array
		               LAST );
		  lr_save_param_regexp (
		    	lr_eval_string("{ToPortCities}"),
		         	strlen(lr_eval_string("{ToPortCities}")),
		               "RegExp=<option value=\"(.*?)\">",
		               "Ordinal=All",
		               "ResultParam=DestinationCityArray",
		               LAST ); 
		       
	lr_think_time(10);	
			 	 	
			web_websocket_send("ID=0", 
				"Buffer={\"messageType\":\"hello\",\"broadcasts\":{\"remote-settings/monitor_changes\":\"\\\"1611539904877\\\"\"},\"use_webpush\":true}", 
				"IsBinary=0", 
				LAST);
		
			/*Connection ID 0 received buffer WebSocketReceive0*/
		
			
	lr_think_time(10);
			
			/* Randomly select the Departure city and Arrivaval city */
	lr_save_string(lr_paramarr_random("DepartureCityArray"),"C_DepartureCity");
	lr_save_string(lr_paramarr_random("DestinationCityArray"),"C_ArrivalCity");
			
			web_reg_save_param_ex("ParamName=Flightcode","LB=<form name=","RB= </form>","Ordinal=ALL",LAST);
			
			web_reg_find("Text=Flights from {C_DepartureCity} to {C_ArrivalCity}:",LAST);
			lr_start_transaction("Blazedemo_randomlycitiespage_T02");
			
			web_submit_data("reserve.php",
				"Action=https://www.blazedemo.com/reserve.php",
				"Method=POST",
				"TargetFrame=",
				"RecContentType=text/html",
				"Referer=https://www.blazedemo.com/",
				"Snapshot=t2.inf",
				"Mode=HTML",
				ITEMDATA,
				"Name=fromPort", "Value={C_DepartureCity}", ENDITEM,
				"Name=toPort", "Value={C_ArrivalCity}", ENDITEM,
				LAST);
	lr_end_transaction("Blazedemo_randomlycitiespage_T02",LR_AUTO);
		lr_save_string(lr_paramarr_random("Flightcode"),"C_RandomFlightarray");
			 lr_save_param_regexp (
				lr_eval_string("{C_RandomFlightarray}"),
		       		strlen(lr_eval_string("{C_RandomFlightarray}")),
		               "RegExp=<input type=\"hidden\" value=\"(.*?)\" name=\"flight\">",
		               "Ordinal=1",
		               "ResultParam=C_FlightNum",
		               LAST ); 
		               
		    lr_save_param_regexp(
			               lr_eval_string("{C_RandomFlightarray}"),
		                  strlen(lr_eval_string("{C_RandomFlightarray}")),
		               	  "RegExp=<input type=\"hidden\" value=\"(.*?)\" name=\"price\">",
		               	  "Ordinal=1",
		               	  "ResultParam=C_Price",
		               	   LAST);
		    lr_save_param_regexp (
						  lr_eval_string("{C_RandomFlightarray}"),
					      strlen(lr_eval_string("{C_RandomFlightarray}")),
					      "RegExp=<input type=\"hidden\" value=\"(.*?)\" name=\"airline\">",//<input type="hidden" value="Lufthansa" name="airline">
					      "Ordinal=1",
					      "ResultParam=C_AirLine",
		               LAST ); 
		      lr_think_time(10);
		                     						
		
			/* choose the random flight */
			web_reg_find("Text=Your flight from ",LAST);
			lr_start_transaction("Blazedemo_randomlyselectFlights_T03");
			web_submit_data("purchase.php",
				"Action=https://www.blazedemo.com/purchase.php",
				"Method=POST",
				"TargetFrame=",
				"RecContentType=text/html",
				"Referer=https://www.blazedemo.com/reserve.php",
				"Snapshot=t3.inf",
				"Mode=HTML",
				ITEMDATA,
				"Name=flight", "Value={C_FlightNum}", ENDITEM,
				"Name=price", "Value={C_Price}", ENDITEM,//432.98
				"Name=airline", "Value={C_AirLine}", ENDITEM,//United Airlines
				"Name=fromPort", "Value={C_DepartureCity}", ENDITEM,
				"Name=toPort", "Value={C_ArrivalCity}", ENDITEM,
				LAST);
			lr_end_transaction("Blazedemo_randomlyselectFlights_T03",LR_AUTO);
		
			/* Enter payment details*/
			lr_think_time(10);
		//  <td>1611786867273</td>
			web_reg_save_param_ex("ParamName=C_Id","LB=<td>","RB=</td>","Ordinal=2",LAST);
			web_reg_find("Text=Thank you for your purchase today",LAST);
			lr_start_transaction("Blazedemo_purchaseFlights_T04");
			web_submit_data("confirmation.php",
				"Action=https://www.blazedemo.com/confirmation.php",
				"Method=POST",
				"TargetFrame=",
				"RecContentType=text/html",
				"Referer=https://www.blazedemo.com/purchase.php",
				"Snapshot=t4.inf",
				"Mode=HTML",
				ITEMDATA,
				"Name=_token", "Value={C_Id}", ENDITEM,
				"Name=inputName", "Value=first", ENDITEM,
				"Name=address", "Value=street1", ENDITEM,
				"Name=city", "Value=city1", ENDITEM,
				"Name=state", "Value=state1", ENDITEM,
				"Name=zipCode", "Value=12345", ENDITEM,
				"Name=cardType", "Value=visa", ENDITEM,
				"Name=creditCardNumber", "Value=12345678", ENDITEM,
				"Name=creditCardMonth", "Value=1", ENDITEM,
				"Name=creditCardYear", "Value=2022", ENDITEM,
				"Name=nameOnCard", "Value=first", ENDITEM,
				LAST);
		
			lr_end_transaction("Blazedemo_purchaseFlights_T04",LR_AUTO);
				
				
			return 0;
		}