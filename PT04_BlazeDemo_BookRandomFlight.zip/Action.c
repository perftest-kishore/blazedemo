Action()
{

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_auto_header("Accept-Language", 
		"en-US");

	
	

	web_set_max_html_param_len("9999999");
	
	web_reg_save_param_ex(
		"ParamName=CFromPortResponse",
		"LB=<select name=\"fromPort\" class=\"form-inline\">\n            ",
		"RB=\n        </select>\n",
		SEARCH_FILTERS,
		LAST);
	
	

	
	web_reg_save_param_ex(
		"ParamName=CToPortResponse",
		"LB=<select name=\"toPort\" class=\"form-inline\">\n            ",
		"RB=\n        </select>\n",
		SEARCH_FILTERS,
		LAST);
	



	lr_start_transaction("PT04_BlazeDemo_T01LaunchIndexPage");

		web_url("index.php", 
		"URL=https://blazedemo.com/index.php", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	lr_end_transaction("PT04_BlazeDemo_T01LaunchIndexPage", LR_AUTO);

	
	
	
	lr_save_param_regexp(lr_eval_string("{CFromPortResponse}"), 
	                     strlen(lr_eval_string("{CFromPortResponse}")),
	                     "RegExp=<option value=\"(.*?)\">", 
	                     "Ordinal=ALL", 
	                     "ResultParam=CFromPortCityDropdown",LAST);

	//lr_paramarr_random("CFromPortCityDropdown");

	
	
    lr_save_param_regexp(lr_eval_string("{CToPortResponse}"), 
	                     strlen(lr_eval_string("{CToPortResponse}")),
	                     "RegExp=<option value=\"(.*?)\">", 
	                     "Ordinal=ALL", 
	                     "ResultParam=CToPortCityDropdown",LAST);

	    
	lr_save_string(lr_paramarr_random("CFromPortCityDropdown"), "CFromPortCity");
	lr_save_string(lr_paramarr_random("CToPortCityDropdown"), "CToPortCity");

	
	    
	/* find flights */

	web_reg_save_param_ex(
		"ParamName=CFlightFormDataArray",
		"LB=                <td><input type=\"submit\" class=\"btn btn-small\" value=\"Choose This Flight\"></td>",
		"RB=\"/>\n            </form>\n",
		"Ordinal=ALL",
		SEARCH_FILTERS,
		LAST);


	lr_start_transaction("PT04_BlazeDemo_T02FindFlights");

		web_submit_data("reserve.php", 
		"Action=https://blazedemo.com/reserve.php", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://blazedemo.com/index.php", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=fromPort", "Value={CFromPortCity}", ENDITEM, 
		"Name=toPort", "Value={CToPortCity}", ENDITEM, 
		EXTRARES, 
		"Url=/favicon.ico", "Referer=", ENDITEM, 
		"Url=/img/glyphicons-halflings.png", ENDITEM, 
		LAST);

	lr_end_transaction("PT04_BlazeDemo_T02FindFlights", LR_AUTO);

	
	lr_save_string(lr_paramarr_random("CFlightFormDataArray"), "CChooseFlightArray");
	
	
	/*
	
	<input type="hidden" value="4346" name="flight">
     <input type="hidden" value="233.98" name="price">
     <input type="hidden" value="Lufthansa" name="airline">*/

	
	lr_save_param_regexp(lr_eval_string("{CChooseFlightArray}"), 
	                     strlen(lr_eval_string("{CChooseFlightArray}")),
	                     "RegExp=<input type=\"hidden\" value=\"(.*?)\" name=\"flight\">",
	                     "Ordinal=ALL", 
	                     "ResultParam=CFlightID",LAST);
	
	
	lr_save_param_regexp(lr_eval_string("{CChooseFlightArray}"), 
	                     strlen(lr_eval_string("{CChooseFlightArray}")),
	                     "RegExp=<input type=\"hidden\" value=\"(.*?)\" name=\"price\">",
	                     "Ordinal=ALL", 
	                     "ResultParam=Cprice",LAST);
	
	
	lr_save_param_regexp(lr_eval_string("{CChooseFlightArray}"), 
	                     strlen(lr_eval_string("{CChooseFlightArray}")),
	                     "RegExp=<input type=\"hidden\" value=\"(.*?)\" name=\"airline\">",
	                     "Ordinal=ALL", 
	                     "ResultParam=CAirline",LAST);
	

	/* choose flight */

	lr_think_time(15);

	lr_start_transaction("PT04_BlazeDemo_T03ChooseRandomFlight");

		web_submit_data("purchase.php", 
		"Action=https://blazedemo.com/purchase.php", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://blazedemo.com/reserve.php", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=flight", "Value={CFlightID}", ENDITEM, //9696
		"Name=price", "Value={CCprice}", ENDITEM, //200.98
		"Name=airline", "Value={CAirline}", ENDITEM, 
		"Name=fromPort", "Value={CFromPortCity}", ENDITEM, //Paris
		"Name=toPort", "Value={CToPortCity}", ENDITEM, //New York
		LAST);

	lr_end_transaction("PT04_BlazeDemo_T03ChooseRandomFlight", LR_AUTO);


	/* urchase flight */

	lr_think_time(21);
	
	

	web_reg_save_param_ex(
		"ParamName=CConfirmationID",
		"LB=<td>Id</td>\n                    <td>",
		"RB=</td>\n                </tr>\n",
		"Ordinal=1",
		SEARCH_FILTERS,
		LAST);

	lr_start_transaction("PT04_BlazeDemo_T04ConfirmPaymentandOrder");

		web_submit_data("confirmation.php", 
		"Action=https://blazedemo.com/confirmation.php", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://blazedemo.com/purchase.php", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=_token", "Value=", ENDITEM, 
		"Name=inputName", "Value=", ENDITEM, 
		"Name=address", "Value=", ENDITEM, 
		"Name=city", "Value=", ENDITEM, 
		"Name=state", "Value=", ENDITEM, 
		"Name=zipCode", "Value=", ENDITEM, 
		"Name=cardType", "Value=visa", ENDITEM, 
		"Name=creditCardNumber", "Value=", ENDITEM, 
		"Name=creditCardMonth", "Value=11", ENDITEM, 
		"Name=creditCardYear", "Value=2017", ENDITEM, 
		"Name=nameOnCard", "Value=", ENDITEM, 
		LAST);

	lr_end_transaction("PT04_BlazeDemo_T04ConfirmPaymentandOrder", LR_AUTO);


	return 0;
}