Action()
{
	web_set_max_html_param_len("1000");
	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_auto_header("Accept", 
		"text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9");

	web_add_auto_header("Sec-Fetch-Site", 
		"none");

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Dest", 
		"document");

	web_add_auto_header("Accept-Encoding", 
		"gzip, deflate, br");

	web_add_auto_header("Accept-Language", 
		"en-US,en;q=0.9");

	web_add_auto_header("Sec-Fetch-User", 
		"?1");

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");

	web_add_auto_header("sec-ch-ua", 
		"\" Not;A Brand\";v=\"99\", \"Google Chrome\";v=\"91\", \"Chromium\";v=\"91\"");

	web_add_auto_header("sec-ch-ua-mobile", 
		"?0");
	
	/*<select name="fromPort" class="form-inline">
            <option value="Paris">Paris</option>
            <option value="Philadelphia">Philadelphia</option>
            <option value="Boston">Boston</option>
            <option value="Portland">Portland</option>
            <option value="San Diego">San Diego</option>
            <option value="Mexico City">Mexico City</option>
            <option value="S�o Paolo">S�o Paolo</option>
        </select>*/
		
	web_reg_save_param_ex("ParamName=C_fromCityCode","LB=<select name=\"fromPort\" class=\"form-inline\">\n            ","RB=\n        </select>",LAST);
	
	web_reg_save_param_ex("ParamName=C_toCityCode","LB=<select name=\"toPort\" class=\"form-inline\">\n            ","RB=\n        </select>",LAST);
	
	//web_reg_save_param_ex("ParamName=C_toCityCode","LB=<select name=\"toPort\" class=\"form-inline\">\n          ","RB=\n          </select>",LAST);
	
	web_url("index.php", 
		"URL=https://www.blazedemo.com/index.php", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/favicon.ico", ENDITEM, 
		LAST);

	/*Possible OAUTH authorization was detected. It is recommended to correlate the authorization parameters.*/

	lr_start_transaction("Choose departAndDestinationCityAndFindFlights");

	web_add_auto_header("Cache-Control", 
		"max-age=0");

	web_add_auto_header("Origin", 
		"https://www.blazedemo.com");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	lr_think_time(42);
	
	lr_save_param_regexp(lr_eval_string("{C_fromCityCode}"),
	                     strlen(lr_eval_string("{C_fromCityCode}")),
	                     "RegExp=<option value=\"(.*?)\">",
	                     "ordinal=all",
	                     "ResultParam=C_DepartCitiesArray",
	                     LAST);
	
	lr_save_param_regexp(lr_eval_string("{C_toCityCode}"),
	                     strlen(lr_eval_string("{C_toCityCode}")),
	                     "RegExp=<option value=\"(.*?)\">",
	                     "ordinal=all",
	                     "ResultParam=C_DestinationCitiesArray",
	                     LAST);
	
	lr_save_string(lr_paramarr_random("C_DepartCitiesArray"),"C_DepatureCity");
	
	lr_save_string(lr_paramarr_random("C_DestinationCitiesArray"),"C_DestinationCity");
	
	/*<form name="VA12" method="post" action="purchase.php">
                <td><input type="submit" class="btn btn-small" value="Choose This Flight"></td>
                <td>12</td>
                <td>Virgin America</td>
                <td>11:23 AM</td>
                <td>1:45 PM</td>
                <td>$765.32</td>
                <input type="hidden" value="12" name="flight">
                <input type="hidden" value="765.32" name="price">
                <input type="hidden" value="Virgin America" name="airline">
                <input type="hidden" name="fromPort" value="S�o Paolo"/>
                <input type="hidden" name="toPort" value="London"/>
            </form>
	 */
	
	web_reg_save_param_ex("ParamName=C_ChooseFlight","LB=<input type=\"submit\" class=\"btn btn-small\" value=\"Choose This Flight\"></td>\n                ","RB=\n            </form>","Ordinal=ALL",LAST);

	web_submit_data("reserve.php", 
		"Action=https://www.blazedemo.com/reserve.php", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://www.blazedemo.com/index.php", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=fromPort", "Value={C_DepatureCity}", ENDITEM, //Paris
		"Name=toPort", "Value={C_DestinationCity}", ENDITEM, //Buenos Aires
		LAST);

	lr_end_transaction("Choose departAndDestinationCityAndFindFlights",LR_AUTO);
	

	lr_think_time(52);

	lr_start_transaction("SelectFlightRandomly");
	
	lr_save_string(lr_paramarr_random("C_ChooseFlight"),"C_Temp1");
	
	//value="(.*?)" name="flight">
	
	lr_save_param_regexp(lr_eval_string("{C_Temp1}"),
	                     strlen(lr_eval_string("{C_Temp1}")),
	                     "RegExp=value=\"(.*?)\" name=\"flight\">",
	                     "ordinal=all",
	                     "ResultParam=C_RandomFlight",
	                     LAST);
	
	//value="(.*?)" name="price">
	
	lr_save_param_regexp(lr_eval_string("{C_Temp1}"),
	                     strlen(lr_eval_string("{C_Temp1}")),
	                     "RegExp=value=\"(.*?)\" name=\"price\">",
	                     "ordinal=all",
	                     "ResultParam=C_FlightPrice",
	                     LAST);
	
	//value="(.*?)" name="airline">
	
	lr_save_param_regexp(lr_eval_string("{C_Temp1}"),
	                     strlen(lr_eval_string("{C_Temp1}")),
	                     "RegExp=value=\"(.*?)\" name=\"airline\">",
	                     "ordinal=all",
	                     "ResultParam=C_Airline",
	                     LAST);
	
	lr_save_string(lr_paramarr_random("C_RandomFlight"),"C_SelectRandomFlight");
	
	lr_save_string(lr_paramarr_random("C_FlightPrice"),"C_Price");
	
	lr_save_string(lr_paramarr_random("C_Airline"),"C_SelectAirLine");
	
//return 0;
	web_submit_data("purchase.php", 
		"Action=https://www.blazedemo.com/purchase.php", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://www.blazedemo.com/reserve.php", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=flight", "Value={C_SelectRandomFlight}", ENDITEM, //9696
		"Name=price", "Value={C_Price}", ENDITEM, 				//200.98
		"Name=airline", "Value={C_SelectAirLine}", ENDITEM, 	//Aer Lingus
		"Name=fromPort", "Value={C_DepatureCity}", ENDITEM, 		//paris
		"Name=toPort", "Value={C_DestinationCity}", ENDITEM, 		//Buenos Aires
		LAST);

	lr_end_transaction("SelectFlightRandomly",LR_AUTO);

	lr_think_time(17);

	lr_start_transaction("PaymentDetails");

	web_submit_data("confirmation.php", 
		"Action=https://www.blazedemo.com/confirmation.php", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://www.blazedemo.com/purchase.php", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=_token", "Value=", ENDITEM, 
		"Name=inputName", "Value=PtTest", ENDITEM, 
		"Name=address", "Value=srnagar", ENDITEM, 
		"Name=city", "Value=hyderabad", ENDITEM, 
		"Name=state", "Value=andhrapradesh", ENDITEM, 
		"Name=zipCode", "Value=524345", ENDITEM, 
		"Name=cardType", "Value=visa", ENDITEM, 
		"Name=creditCardNumber", "Value=45525452244", ENDITEM, 
		"Name=creditCardMonth", "Value=11", ENDITEM, 
		"Name=creditCardYear", "Value=2021", ENDITEM, 
		"Name=nameOnCard", "Value=PtTest", ENDITEM, 
		LAST);

	lr_end_transaction("PaymentDetails",LR_AUTO);

	return 0;
}